from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, make_response
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
import os
import json
from datetime import datetime
import io
from ocr_processor import extract_text_from_pdf
from models.disease_predictor import predict_disease, get_recommendations

app = Flask(__name__)
app.secret_key = 'healthscanai_secret_key_2025'
app.config['DATABASE'] = 'instance/database.db'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Add JSON filter for templates
@app.template_filter('from_json')
def from_json(value):
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return []

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('instance', exist_ok=True)

# Allowed file extensions
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def init_db():
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Check if reports table exists and has the disease_probabilities column
    try:
        cursor.execute("SELECT disease_probabilities FROM reports LIMIT 1")
    except sqlite3.OperationalError:
        # Column doesn't exist, add it
        try:
            cursor.execute("ALTER TABLE reports ADD COLUMN disease_probabilities TEXT")
        except sqlite3.OperationalError:
            # Table doesn't exist, create it
            cursor.execute('''
                CREATE TABLE reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    filename TEXT NOT NULL,
                    patient_name TEXT,
                    patient_age INTEGER,
                    patient_gender TEXT,
                    extracted_text TEXT,
                    disease_prediction TEXT,
                    disease_probabilities TEXT,
                    diet_recommendations TEXT,
                    health_precautions TEXT,
                    health_score INTEGER,
                    analysis_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    report_category TEXT DEFAULT 'General',
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            ''')
    
    # Check if report_category column exists, if not add it
    try:
        cursor.execute("SELECT report_category FROM reports LIMIT 1")
    except sqlite3.OperationalError:
        try:
            cursor.execute("ALTER TABLE reports ADD COLUMN report_category TEXT DEFAULT 'General'")
        except sqlite3.OperationalError:
            pass  # Column might already exist or table structure is different
    
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        conn = sqlite3.connect(app.config['DATABASE'])
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE email = ?', (email,))
        user = cursor.fetchone()
        conn.close()
        
        if user and check_password_hash(user[3], password):
            session['user_id'] = user[0]
            session['user_name'] = user[1]
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('register.html')
        
        hashed_password = generate_password_hash(password)
        
        try:
            conn = sqlite3.connect(app.config['DATABASE'])
            cursor = conn.cursor()
            cursor.execute('INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)',
                         (full_name, email, hashed_password))
            conn.commit()
            conn.close()
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Email already exists', 'error')
    
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Get selected category from query params, default to 'All'
    selected_category = request.args.get('category', 'All')
    
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    
    # Get user's reports with explicit column selection to ensure correct order
    if selected_category == 'All':
        cursor.execute('''
            SELECT id, user_id, filename, patient_name, patient_age, patient_gender, 
                   extracted_text, disease_prediction, disease_probabilities, diet_recommendations, 
                   health_precautions, health_score, analysis_date, report_category
            FROM reports 
            WHERE user_id = ? 
            ORDER BY analysis_date DESC 
            LIMIT 3
        ''', (session['user_id'],))
    else:
        cursor.execute('''
            SELECT id, user_id, filename, patient_name, patient_age, patient_gender, 
                   extracted_text, disease_prediction, disease_probabilities, diet_recommendations, 
                   health_precautions, health_score, analysis_date, report_category
            FROM reports 
            WHERE user_id = ? AND report_category = ?
            ORDER BY analysis_date DESC 
            LIMIT 3
        ''', (session['user_id'], selected_category))
    
    reports = cursor.fetchall()
    
    # Get all unique categories for the filter
    cursor.execute('SELECT DISTINCT report_category FROM reports WHERE user_id = ?', (session['user_id'],))
    categories = [row[0] for row in cursor.fetchall()]
    
    # Get stats
    cursor.execute('SELECT COUNT(*), AVG(health_score) FROM reports WHERE user_id = ?', 
                   (session['user_id'],))
    stats = cursor.fetchone()
    
    # Get last analysis date
    cursor.execute('SELECT MAX(analysis_date) FROM reports WHERE user_id = ?', 
                   (session['user_id'],))
    last_analysis = cursor.fetchone()
    
    conn.close()
    
    total_reports = stats[0] if stats[0] else 0
    avg_health_score = round(stats[1]) if stats[1] else 0
    last_analysis_date = last_analysis[0] if last_analysis and last_analysis[0] else 'N/A'
    
    # Ensure health_score in reports is integer
    processed_reports = []
    for report in reports:
        # Convert health_score to int if it's not already
        report_list = list(report)
        if report_list[11] is not None:
            try:
                report_list[11] = int(report_list[11])
            except (ValueError, TypeError):
                report_list[11] = 0
        else:
            report_list[11] = 0
        processed_reports.append(tuple(report_list))
    
    return render_template('dashboard.html', 
                         reports=processed_reports,
                         total_reports=total_reports,
                         avg_health_score=avg_health_score,
                         last_analysis_date=last_analysis_date,
                         user_name=session['user_name'],
                         categories=categories,
                         selected_category=selected_category)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Define report categories
    report_categories = [
        ('General', 'General Health Checkup'),
        ('CBC', 'Complete Blood Count (CBC)'),
        ('KFT', 'Kidney Function Test (KFT)'),
        ('LFT', 'Liver Function Test (LFT)'),
        ('TFT', 'Thyroid Function Test (TFT)'),
        ('Lipid', 'Lipid Profile')
    ]
    
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected', 'error')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(request.url)
        
        # Get report category
        report_category = request.form.get('report_category', 'General')
        
        if file and allowed_file(file.filename):
            # Save file
            filename = f"{session['user_id']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{secure_filename(file.filename)}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Extract text from PDF
            extracted_text = extract_text_from_pdf(filepath)
            
            # Get patient details
            patient_name = request.form.get('patient_name', '')
            patient_age = request.form.get('patient_age', '')
            patient_gender = request.form.get('patient_gender', '')
            
            # Ensure age is properly formatted
            if patient_age == '':
                patient_age = '0'
            
            # Analyze report
            analysis_result = analyze_medical_report(extracted_text, patient_age, patient_gender)
            
            # Save to database
            conn = sqlite3.connect(app.config['DATABASE'])
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO reports 
                (user_id, filename, patient_name, patient_age, patient_gender, 
                 extracted_text, disease_prediction, disease_probabilities, diet_recommendations, 
                 health_precautions, health_score, analysis_date, report_category)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)
            ''', (session['user_id'], filename, patient_name, patient_age, patient_gender,
                  extracted_text, analysis_result['disease_prediction'],
                  analysis_result.get('disease_probabilities', '[]'),
                  analysis_result['diet_recommendations'], 
                  analysis_result['health_precautions'],
                  analysis_result['health_score'], report_category))
            
            report_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            return redirect(url_for('result', report_id=report_id))
        else:
            flash('Invalid file type. Please upload a PDF, PNG, JPG, or JPEG file.', 'error')
    
    # For GET request, pass report categories to template
    return render_template('upload.html', report_categories=[
        ('General', 'General Health Checkup'),
        ('CBC', 'Complete Blood Count (CBC)'),
        ('KFT', 'Kidney Function Test (KFT)'),
        ('LFT', 'Liver Function Test (LFT)'),
        ('TFT', 'Thyroid Function Test (TFT)'),
        ('Lipid', 'Lipid Profile')
    ])

def analyze_medical_report(text, age, gender):
    # Use comprehensive approach with ML models
    from models.disease_predictor import ComprehensiveHealthScanAI
    analyzer = ComprehensiveHealthScanAI()
    
    # Analyze medical report
    analysis_result = analyzer.analyze_medical_report(text, age, gender)
    
    return analysis_result

@app.route('/result/<int:report_id>')
def result(report_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    cursor.execute('SELECT id, user_id, filename, patient_name, patient_age, patient_gender, extracted_text, disease_prediction, disease_probabilities, diet_recommendations, health_precautions, health_score, analysis_date, report_category FROM reports WHERE id = ? AND user_id = ?', 
                   (report_id, session['user_id']))
    report = cursor.fetchone()
    conn.close()
    
    if not report:
        flash('Report not found', 'error')
        return redirect(url_for('dashboard'))
    
    # Parse diet recommendations, health precautions, and disease probabilities if they are stored as JSON strings
    disease_prediction = report[7] if report[7] is not None else ''
    disease_probabilities = report[8] if report[8] is not None else '[]'
    diet_recommendations = report[9] if report[9] is not None else '{}'
    health_precautions = report[10] if report[10] is not None else '[]'
    health_score = report[11] if report[11] is not None else 0
    analysis_date = report[12] if report[12] is not None else ''
    report_category = report[13] if report[13] is not None else 'General'
    
    # Ensure health_score is an integer
    try:
        health_score = int(health_score)
    except (ValueError, TypeError):
        health_score = 0
    
    try:
        disease_probabilities = json.loads(disease_probabilities)
    except (json.JSONDecodeError, TypeError):
        disease_probabilities = []
        
    try:
        diet_recommendations = json.loads(diet_recommendations)
    except (json.JSONDecodeError, TypeError):
        diet_recommendations = {"recommend": [], "avoid": []}
    
    try:
        health_precautions = json.loads(health_precautions)
    except (json.JSONDecodeError, TypeError):
        health_precautions = []
    
    # Create a new report tuple with parsed data
    parsed_report = (report[0], report[1], report[2], report[3], report[4], report[5], report[6], 
                     disease_prediction, disease_probabilities, diet_recommendations, health_precautions, 
                     health_score, analysis_date, report_category)
    
    return render_template('result.html', report=parsed_report)

@app.route('/delete_report/<int:report_id>')
def delete_report(report_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    # Delete report only if it belongs to the current user
    cursor.execute('DELETE FROM reports WHERE id = ? AND user_id = ?', 
                   (report_id, session['user_id']))
    conn.commit()
    conn.close()
    
    flash('Report deleted successfully', 'success')
    return redirect(url_for('dashboard'))

@app.route('/download_pdf/<int:report_id>')
def download_pdf(report_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    cursor.execute('SELECT id, user_id, filename, patient_name, patient_age, patient_gender, extracted_text, disease_prediction, disease_probabilities, diet_recommendations, health_precautions, health_score, analysis_date, report_category FROM reports WHERE id = ? AND user_id = ?', 
                   (report_id, session['user_id']))
    report = cursor.fetchone()
    conn.close()
    
    if not report:
        flash('Report not found', 'error')
        return redirect(url_for('dashboard'))
    
    # Parse data
    disease_prediction = report[7] if report[7] is not None else ''
    disease_probabilities = report[8] if report[8] is not None else '[]'
    diet_recommendations = report[9] if report[9] is not None else '{}'
    health_precautions = report[10] if report[10] is not None else '[]'
    health_score = report[11] if report[11] is not None else 0
    analysis_date = report[12] if report[12] is not None else ''
    report_category = report[13] if report[13] is not None else 'General'
    
    # Ensure health_score is an integer
    try:
        health_score = int(health_score)
    except (ValueError, TypeError):
        health_score = 0
    
    try:
        disease_probabilities = json.loads(disease_probabilities)
    except (json.JSONDecodeError, TypeError):
        disease_probabilities = []
        
    try:
        diet_recommendations = json.loads(diet_recommendations)
    except (json.JSONDecodeError, TypeError):
        diet_recommendations = {"recommend": [], "avoid": []}
    
    try:
        health_precautions = json.loads(health_precautions)
    except (json.JSONDecodeError, TypeError):
        health_precautions = []
    
    # Create a simple text-based PDF content (in a real implementation, you would use a PDF library)
    # For now, we'll return a text file with the analysis data
    pdf_content = f"""HealthScanAI Medical Report Analysis
=================================

Patient Information:
-------------------
Patient Name: {report[3] if report[3] else 'N/A'}
Age: {report[4] if report[4] else 'N/A'}
Gender: {report[5] if report[5] else 'N/A'}
Report Category: {report_category}
Analysis Date: {report[12][:10] if report[12] else 'N/A'}

Health Score:
------------
Overall Health Score: {health_score}/100

Health Condition Probabilities:
------------------------------
"""
    
    if disease_probabilities and isinstance(disease_probabilities, list):
        for prob_item in disease_probabilities:
            if isinstance(prob_item, str) and ':' in prob_item:
                pdf_content += f"{prob_item}\n"
            else:
                pdf_content += f"{prob_item}\n"
    else:
        pdf_content += "No significant conditions detected\n"
    
    pdf_content += f"""

Dietary Recommendations:
-----------------------
Foods to Eat:
"""
    
    if isinstance(diet_recommendations, dict) and 'recommend' in diet_recommendations:
        for item in diet_recommendations['recommend']:
            pdf_content += f"- {item}\n"
    else:
        pdf_content += "- Balanced nutrition\n- Fresh fruits and vegetables\n- Lean proteins\n- Whole grains\n"
    
    pdf_content += f"""

Foods to Avoid:
"""
    
    if isinstance(diet_recommendations, dict) and 'avoid' in diet_recommendations:
        for item in diet_recommendations['avoid']:
            pdf_content += f"- {item}\n"
    else:
        pdf_content += "- Processed foods\n- Excessive sugar\n- High sodium foods\n- Trans fats\n"
    
    pdf_content += f"""

Health Precautions:
------------------
"""
    
    if health_precautions and isinstance(health_precautions, list):
        for item in health_precautions:
            pdf_content += f"- {item}\n"
    else:
        pdf_content += "- Regular exercise\n- Adequate sleep\n- Stress management\n- Annual checkups\n"
    
    pdf_content += f"""

Disclaimer:
----------
This health analysis is provided for informational purposes only and is not intended as a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition. The predictions and recommendations provided by HealthScanAI are based on AI analysis and should be used as a supplement to, not a replacement for, professional healthcare consultation.

Report generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

    # Create response with PDF content
    response = make_response(pdf_content)
    response.headers['Content-Type'] = 'text/plain'
    response.headers['Content-Disposition'] = f'attachment; filename=health_report_{report_id}.txt'
    
    return response

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('index'))

@app.route('/history')
def history():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Get selected category from query params, default to 'All'
    selected_category = request.args.get('category', 'All')
    
    conn = sqlite3.connect(app.config['DATABASE'])
    cursor = conn.cursor()
    
    # Get user's reports with explicit column selection to ensure correct order
    if selected_category == 'All':
        cursor.execute('''
            SELECT id, user_id, filename, patient_name, patient_age, patient_gender, 
                   extracted_text, disease_prediction, disease_probabilities, diet_recommendations, 
                   health_precautions, health_score, analysis_date, report_category
            FROM reports 
            WHERE user_id = ? 
            ORDER BY analysis_date DESC
        ''', (session['user_id'],))
    else:
        cursor.execute('''
            SELECT id, user_id, filename, patient_name, patient_age, patient_gender, 
                   extracted_text, disease_prediction, disease_probabilities, diet_recommendations, 
                   health_precautions, health_score, analysis_date, report_category
            FROM reports 
            WHERE user_id = ? AND report_category = ?
            ORDER BY analysis_date DESC
        ''', (session['user_id'], selected_category))
    
    reports = cursor.fetchall()
    
    # Get all unique categories for the filter
    cursor.execute('SELECT DISTINCT report_category FROM reports WHERE user_id = ?', (session['user_id'],))
    categories = [row[0] for row in cursor.fetchall()]
    
    # Prepare data for charts (health score trend over time)
    chart_data = []
    for report in reports:
        chart_data.append({
            'date': report[12][:10] if report[12] else 'N/A',  # analysis_date
            'score': int(report[11]) if report[11] is not None else 0,  # health_score
            'category': report[13] if report[13] else 'General'  # report_category
        })
    
    conn.close()
    
    # Ensure health_score in reports is integer
    processed_reports = []
    for report in reports:
        # Convert health_score to int if it's not already
        report_list = list(report)
        if report_list[11] is not None:
            try:
                report_list[11] = int(report_list[11])
            except (ValueError, TypeError):
                report_list[11] = 0
        else:
            report_list[11] = 0
        processed_reports.append(tuple(report_list))
    
    return render_template('history.html', 
                         reports=processed_reports,
                         chart_data=chart_data,
                         user_name=session['user_name'],
                         categories=categories,
                         selected_category=selected_category)

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)