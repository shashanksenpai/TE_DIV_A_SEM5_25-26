import sqlite3

# Connect to the database
conn = sqlite3.connect('instance/database.db')
cursor = conn.cursor()

# Get table info
cursor.execute('PRAGMA table_info(reports)')
columns = cursor.fetchall()

print("Reports table structure:")
for col in columns:
    print(f"  {col[1]} ({col[2]}) - Not Null: {bool(col[3])} - Default: {col[4]} - PK: {col[5]}")

# Get a sample record
cursor.execute('SELECT * FROM reports LIMIT 1')
sample = cursor.fetchone()

if sample:
    print("\nSample record:")
    for i, (col, value) in enumerate(zip(columns, sample)):
        print(f"  {col[1]}: {value}")

conn.close()