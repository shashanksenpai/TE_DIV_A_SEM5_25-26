import sys
import os
sys.path.append('.')

from models.disease_predictor import ComprehensiveHealthScanAI

def test_comprehensive_system():
    """Test the comprehensive HealthScanAI system"""
    print("🧪 Testing Comprehensive HealthScanAI System...")
    
    # Initialize the analyzer
    analyzer = ComprehensiveHealthScanAI()
    
    # Test cases
    test_cases = [
        {
            'name': 'Diabetes Patient',
            'text': 'Type 2 diabetes with HbA1c 8.2%. Fasting glucose 156 mg/dL. Lipid profile: Total cholesterol 220. Blood pressure 135/85.',
            'age': 55,
            'gender': 'Male'
        },
        {
            'name': 'Hypertension Patient',
            'text': 'Blood pressure elevated at 155/95 mmHg. Stage 2 hypertension. Lipid panel: Total cholesterol 240 mg/dL. Recommended lifestyle modifications.',
            'age': 60,
            'gender': 'Female'
        },
        {
            'name': 'Healthy Patient',
            'text': 'Routine health maintenance. Blood pressure 115/75 mmHg. All parameters normal. Lipid panel: cholesterol 180 mg/dL.',
            'age': 35,
            'gender': 'Male'
        },
        {
            'name': 'High Cholesterol Patient',
            'text': 'Hyperlipidemia with total cholesterol 280 mg/dL. LDL 180 mg/dL, HDL 35 mg/dL. Blood pressure 125/80.',
            'age': 45,
            'gender': 'Female'
        }
    ]
    
    for i, case in enumerate(test_cases, 1):
        print(f"\n--- Test Case {i}: {case['name']} ---")
        print(f"Medical Report: {case['text']}")
        print(f"Age: {case['age']}, Gender: {case['gender']}")
        
        # Analyze the report
        result = analyzer.analyze_medical_report(case['text'], case['age'], case['gender'])
        
        print(f"\nDisease Prediction: {result['disease_prediction']}")
        print(f"Health Score: {result['health_score']}/100")
        print(f"Analysis Method: {result['analysis_method']}")
        
        # Parse recommendations
        diet_recs = eval(result['diet_recommendations'])
        lifestyle_recs = eval(result['health_precautions'])
        
        print("\nDiet Recommendations:")
        for rec in diet_recs.get('recommend', []):
            print(f"  ✓ {rec}")
        
        print("\nFoods to Avoid:")
        for rec in diet_recs.get('avoid', []):
            print(f"  ✗ {rec}")
        
        print("\nLifestyle Recommendations:")
        for rec in lifestyle_recs:
            print(f"  ✓ {rec}")

if __name__ == "__main__":
    test_comprehensive_system()